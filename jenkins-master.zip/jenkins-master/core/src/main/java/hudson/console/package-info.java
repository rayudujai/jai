/**
 * Beef up the plain text console output by adding HTML markup.
 */
package hudson.console;
