#CucumberBasic
This is an sample project to demonstrate how to work with Selenium and cucumber for Java

##More Information
The complete code base development video is available in ExecuteAutomation YouTube channel 

https://www.youtube.com/playlist?list=PL6tu16kXT9PpteusHGISu_lHcV6MbBtA6

##Cucumber with Selenium video Series
https://www.youtube.com/playlist?list=PL6tu16kXT9Pqr70SZlwcmTSAfOw_0Qj3R

###For more articles and videos
Visit http://www.executeautomation.com
