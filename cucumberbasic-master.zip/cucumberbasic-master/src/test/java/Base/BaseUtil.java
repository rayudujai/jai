package Base;

/**
 * Created by Karthik on 10/21/2016.
 */
public class BaseUtil {

    public String StepInfo;

}
