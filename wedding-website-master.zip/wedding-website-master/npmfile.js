exports.printMsg = function() {
    console.log("Visit https://wedding.rampatra.com !");
};